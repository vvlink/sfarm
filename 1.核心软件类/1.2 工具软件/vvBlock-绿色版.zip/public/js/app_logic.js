/**
 * @license Licensed under the Apache License, Version 2.0 (the "License"):
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 * @fileoverview Description.
 */
'use strict';

var Bgpio = Bgpio || {};

Bgpio.workspace = null;
Bgpio.DEBUG = true;
Bgpio.PIN_COUNT = 26;

Bgpio.init = function () {
  Bgpio.workspace = Blockly.inject('blocklyDiv', {
      media: 'blockly/media/',
      toolbox: document.getElementById('toolbox')

  });

  
  
  //var modeText = document.getElementById('modeExecution');
  //modeText.style.display='inline';
  //var simulationContent = document.getElementById('simulationContentDiv');
  var executionContent = document.getElementById('executionContentDiv');
  //simulationContent.style.display = 'none';
  executionContent.style.display = 'block';
          
  Bgpio.workspace.addChangeListener(Bgpio.renderPythonCode);
  //Bgpio.clearJsConsole();
  //Bgpio.WebSocket.init();
};




function load(event) {
   if(window.removeEventListener){
     window.removeEventListener('load', load, false);
       
    }else{
        window.detachEvent("onload",load);
    } 
  
  //兼容ie9  
  window.console = window.console || (function(){
	var c = {}; c.log = c.warn = c.debug = c.info = c.error = c.time = c.dir = c.profile = c.clear = c.exception = c.trace = c.assert = function(){};
		return c;
	})();	
  Bgpio.init();
}


if (window.addEventListener) {    
    window.addEventListener("load", load, false); 
} else {    
   window.attachEvent("onload", load);  
}  






Bgpio.runMode = {
  debugInit: Bgpio.PythonInterpreter.debugInit,
  debugStep: Bgpio.PythonInterpreter.debugStep,
  run: Bgpio.PythonInterpreter.run,
  stop: Bgpio.PythonInterpreter.stop
 };

/*******************************************************************************
 * Blockly related
 ******************************************************************************/
 Bgpio.generateJavaScriptCode = function() {
  return Blockly.JavaScript.workspaceToCode(Bgpio.workspace);
};

Bgpio.generatePythonCode = function() {
  var code=	Blockly.Python.workspaceToCode(Bgpio.workspace);
  if(code.indexOf("from interface.gpio import")!=-1){
	var replace_str="Board(\"xugu\").begin()";
	code=code.replace(replace_str,"");	
  }
  return code;
};

Bgpio.generateXml = function() {
  var xmlDom = Blockly.Xml.workspaceToDom(Bgpio.workspace);
  var xmlText = Blockly.Xml.domToPrettyText(xmlDom);
  return xmlText;
};

Bgpio.renderPythonCode = function() {
  // Only regenerate the code if a block is not being dragged
//   if (Blockly.dragMode_ != 0) {
//     return;
//   }
  // Render Python Code with latest change highlight and syntax highlighting
  var pyPre = document.getElementById('pythonCodePre');
  pyPre.textContent = Bgpio.generatePythonCode();
  pyPre.innerHTML = prettyPrintOne(pyPre.innerHTML, 'py', false);
};

/*******************************************************************************
 *  Right content related
 ******************************************************************************/
// Bgpio.setPinDefaults = function() {
//  for (var i = 1; i <= Bgpio.PIN_COUNT; i++) {
//    document.getElementById('pin' + i).className = 'pinDefault';
//  }
// };

// Bgpio.setPinDigital = function(pinNumber, isPinHigh) {
//   var pin = document.getElementById('pin' + pinNumber);
//   pin.className = isPinHigh ? 'pinDigitalHigh' : 'pinDigitalLow';
// };
// 
// Bgpio.appendTextJsConsole = function(text) {
//   var jsConsole = document.getElementById('jsConsolePre');
//   jsConsole.textContent += text + '\n';
// };

// Bgpio.clearJsConsole = function(text) {
//   var jsConsole = document.getElementById('jsConsolePre');
//   jsConsole.textContent = 'Simulated print output.\n';
// };

/*******************************************************************************
 * Other
 ******************************************************************************/
// Bgpio.getRaspPiIp = function() {
//   var ipField = document.getElementById('raspPiIp');
//   var ip = ipField.value;
//   if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ip)) {
//     ipField.style.color = "green";
//     return ipField.value;
//   }
//   ipField.style.color = "red";
//   return null;
// };
