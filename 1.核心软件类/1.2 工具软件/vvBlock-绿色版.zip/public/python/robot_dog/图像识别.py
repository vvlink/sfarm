﻿import sys

sys.path.append('/home/pi/aicomer/voice')
import VoiceHelper

sys.path.append('/home/pi/aicomer/photo')
import PhotoHelper


VoiceHelper.set_bspd(5)
VoiceHelper.set_bpit(5)
VoiceHelper.set_bvol(9)
VoiceHelper.set_bper(0)
VoiceHelper.say('主人我准备好了')
while True:
  VoiceHelper.say((PhotoHelper.get_photo_result()))
