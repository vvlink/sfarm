import sys

a = None

sys.path.append('/home/pi/aicomer/voice')
import VoiceHelper

sys.path.append('/home/pi/aicomer/tftdisplay')
import EyeHelper


a = True
VoiceHelper.set_bspd(5)
VoiceHelper.set_bvol(9)
VoiceHelper.set_bpit(6)
VoiceHelper.set_bper(0)
while a:
  EyeHelper.display(EyeHelper.HELLO)
  VoiceHelper.say('你好')
