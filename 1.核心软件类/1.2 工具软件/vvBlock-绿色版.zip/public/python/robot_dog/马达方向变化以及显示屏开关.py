import sys
from Adafruit_MotorHAT import Adafruit_MotorHAT
from time import sleep

sys.path.append('/home/pi/aicomer/voice')
import VoiceHelper

sys.path.append('/home/pi/aicomer/tftdisplay')
import EyeHelper

sys.path.append('/home/pi/aicomer/gpio')
import DCHelper


VoiceHelper.set_bspd(4)
VoiceHelper.set_bvol(9)
VoiceHelper.set_bpit(5)
VoiceHelper.set_bper(0)
EyeHelper.display(EyeHelper.ZAJI)
VoiceHelper.say('前进')
DCHelper.MotorManager().getMotor(1).setSpeed(150).run(Adafruit_MotorHAT.BACKWARD)
DCHelper.MotorManager().getMotor(2).setSpeed(150).run(Adafruit_MotorHAT.FORWARD)
DCHelper.MotorManager().getMotor(3).setSpeed(150).run(Adafruit_MotorHAT.FORWARD)
DCHelper.MotorManager().getMotor(4).setSpeed(150).run(Adafruit_MotorHAT.BACKWARD)
sleep(2);
VoiceHelper.say('后退')
DCHelper.MotorManager().getMotor(1).setSpeed(150).run(Adafruit_MotorHAT.FORWARD)
DCHelper.MotorManager().getMotor(2).setSpeed(150).run(Adafruit_MotorHAT.BACKWARD)
DCHelper.MotorManager().getMotor(3).setSpeed(150).run(Adafruit_MotorHAT.BACKWARD)
DCHelper.MotorManager().getMotor(4).setSpeed(150).run(Adafruit_MotorHAT.FORWARD)
sleep(2);
VoiceHelper.say('左移')
DCHelper.MotorManager().getMotor(1).setSpeed(150).run(Adafruit_MotorHAT.FORWARD)
DCHelper.MotorManager().getMotor(2).setSpeed(150).run(Adafruit_MotorHAT.FORWARD)
DCHelper.MotorManager().getMotor(3).setSpeed(150).run(Adafruit_MotorHAT.BACKWARD)
DCHelper.MotorManager().getMotor(4).setSpeed(150).run(Adafruit_MotorHAT.BACKWARD)
sleep(2);
VoiceHelper.say('右移')
DCHelper.MotorManager().getMotor(1).setSpeed(150).run(Adafruit_MotorHAT.BACKWARD)
DCHelper.MotorManager().getMotor(2).setSpeed(150).run(Adafruit_MotorHAT.BACKWARD)
DCHelper.MotorManager().getMotor(3).setSpeed(150).run(Adafruit_MotorHAT.FORWARD)
DCHelper.MotorManager().getMotor(4).setSpeed(150).run(Adafruit_MotorHAT.FORWARD)
sleep(2);
EyeHelper.display(EyeHelper.CLOSE)
