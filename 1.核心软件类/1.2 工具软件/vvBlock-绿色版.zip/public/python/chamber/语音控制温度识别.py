import sys


sys.path.append('/home/pi/aicomer/voice')
import VoiceHelper

sys.path.append('/home/pi/aicomer/gpio')
import TempHumHelper




openstr=['天气','温度']


def handlresult():
    result=VoiceHelper.get_voice_result()
    if(not result is None):
          print(result)
          for key in openstr:
              if(key in result):
                    loop=True
                    while(loop):
                        temper=(TempHumHelper.TempManager().getTemp(25).getTemperature())
                        #print(temper)
                        if(not temper is None): 
                            loop=False
                        else:
                            from time import sleep
                            sleep(0.2)
                            
                    temperature=int(temper)
                    result='今天天气温度:'+str(temperature)+'摄氏度,  '
                    if(temperature<=23):
                        result+='温度偏低,为了防止感冒,请您酌情添衣,注意保暖'
                    elif(temperature>=29):      
                        result+='温度偏高,请勿长时间在室外活动,防止中暑'
                    else:
                        result+='温度较为平和,可适当增加室外活动时间。'
                    VoiceHelper.say(result)
                    break;




#语音识别 获取温度


while True:
      handlresult()
    
                  




