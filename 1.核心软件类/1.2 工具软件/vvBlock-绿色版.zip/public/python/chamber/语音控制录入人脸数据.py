import sys


sys.path.append('/home/pi/aicomer/voice')
import VoiceHelper


sys.path.append('/home/pi/aicomer/face')
import FaceHelper

sys.path.append('/home/pi/aicomer/gpio')
import ServoHelper





def handlresult():
    global set_name,fn_name
    result=VoiceHelper.get_voice_result()        
    if(not result is None and result.strip()):
            VoiceHelper.say('好的'+result)
            FaceHelper.set_user_name(result)
            VoiceHelper.say('开始采集数据,请正视摄像头')
            count=0
            while(count<20):
                if(FaceHelper.get_photo_issuccess()):
                    count+=1
                VoiceHelper.say('第'+str(count)+'次')
            VoiceHelper.say('采集结束')
            exit()    
#语音识别 获取温度
VoiceHelper.say('请在滴的一声后设置录入人姓名')
while True:
      handlresult()
    
                  




