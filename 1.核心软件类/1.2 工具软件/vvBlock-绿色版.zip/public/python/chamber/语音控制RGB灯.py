import sys
#import os
from time import sleep
#import subprocess

sys.path.append('/home/pi/aicomer/voice')
import VoiceHelper
sys.path.append('/home/pi/aicomer/gpio')
import RGBHelper



openstr=['开','灯','亮']
run_name='/home/pi/aicomer/测试案例/RGBHelper.py'
#当前是否显示
is_opening=False

def open_rgb():
    print('open')
    subprocess.Popen('sudo python3 '+run_name+ ' start', shell=True)
    
def close():
    tmp=os.popen('ps aux |grep '+run_name).read()
    array=tmp.splitlines()
    for line in array:
        if('python3' in line and run_name in line and 'start' in line) :
            pid=int(line.split( )[1])
            os.system('sudo kill -9 %d'%(pid))
            print('kill socket %d -----'%(pid))

def isrunning():
    tmp=os.popen('ps aux |grep '+run_name).read()
    array=tmp.splitlines()
    for line in array:
        if('python3' in line and run_name in line and 'start' in line) :
            return True
    return False   


def handlresult():
    result=VoiceHelper.get_voice_result()
    #print(result)
    global is_opening
    if(not result is None):
          for key in openstr:
              if('绿灯') in result:
                  RGBHelper.setRgbVal(100,0,100)
                  break
              if('红灯') in result:
                  RGBHelper.setRgbVal(0,100,100)
                  break
              if('蓝灯') in result:
                  RGBHelper.setRgbVal(100,100,0)
                  break
              elif('关灯' in result):
                  RGBHelper.setRgb(100,100,100,0,0,0)
                 
             
#语音识别 获取温度
while True:
      handlresult()






