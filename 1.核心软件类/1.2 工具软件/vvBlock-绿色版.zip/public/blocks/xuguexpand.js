
var XUGU_HUE=40;

/** 设置马达转向及转速 */ 
Blockly.Blocks['xugu_set_motor_param'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(XUGU_HUE);
    this.appendDummyInput()
        .appendField('设置马达')
        .appendField(new Blockly.FieldDropdown([
                       ['1', '1'],
                       ['2', '2'],
                       ['3', '3'],
                       ['4', '4']
                     ]),'MOTOR_NUM');
    this.appendDummyInput()
        .appendField('转向')
        .appendField(new Blockly.FieldDropdown([
                       ['正向', '1'],
                       ['反向', '0']
                     ]),'MOTOR_DIREC');    
    this.appendDummyInput()
        .appendField('转速');    
    this.appendValueInput('MOTOR_SPEED', 'Number')
        .setCheck('Number');
        
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('用于设置连接设备马达的转速以及方向');
  }
};
Blockly.Python['xugu_set_motor_param'] = function(block) {
  var motorspeed = Blockly.Python.valueToCode(
      block, 'MOTOR_SPEED', Blockly.Python.ORDER_ATOMIC) || '';
  
  var motornum = block.getFieldValue('MOTOR_NUM');  
  var motordirect = block.getFieldValue('MOTOR_DIREC');

  Blockly.Python.definitions_['import_dcHelper'] = "from interface.gpio import DCHelper";
  
  
  var code = '';
  if(motorspeed<0)
    motorspeed = 0;
  if(motorspeed>255)
     motorspeed=255;
    
  code = code + "DCHelper.motormanager.getMotor("+motornum+").setSpeed("+motorspeed+")"; 


  if(motordirect==1)
    code = code+".run(DCHelper.FORWARD)\n";
  else
    code =code+ ".run(DCHelper.BACKWARD)\n";
  
  
  return code;
};


/** 停止马达运转 */ 
Blockly.Blocks['xugu_stop_motor'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(XUGU_HUE);
    this.appendDummyInput()
        .appendField('设置马达')
        .appendField(new Blockly.FieldDropdown([
                       ['1', '1'],
                       ['2', '2'],
                       ['3', '3'],
                       ['4', '4']
                     ]),'MOTOR_NUM');
    this.appendDummyInput()
        .appendField('停止运行');    
        
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('用于停止连接设备的马达转动');
  }
};

Blockly.Python['xugu_stop_motor'] = function(block) {
  Blockly.Python.definitions_['import_dcHelper'] = "from interface.gpio import DCHelper";
  var motornum = block.getFieldValue('MOTOR_NUM');
  var code = "DCHelper.motormanager.getMotor("+motornum+").run(DCHelper.RELEASE)\n";
  return code;
};
/** 设置舵机角度 */ 
Blockly.Blocks['xugu_set_servo_angle'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(XUGU_HUE);
    this.appendDummyInput()
        .appendField('设置9g舵机')
        .appendField(new Blockly.FieldDropdown([
                       ['5', '5'],
                       ['6', '6'],
                       ['7', '7'],
                       ['13', '13'],
					   ['14', '14'],
					   ['15', '15']
                     ]),'SERVO_NUM');		
    this.appendDummyInput()
        .appendField('角度');    
    this.appendValueInput('SERVO_ANGLE', 'Number')
        .setCheck('Number');
    this.appendDummyInput()
        .appendField('度');     
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('设置连接设备舵机的转向角度');
  }
};

Blockly.Python['xugu_set_servo_angle'] = function(block) {
  Blockly.Python.definitions_['import_servoHelper'] = "from interface.gpio import ServoHelper";
  var servoangel = Blockly.Python.valueToCode(
      block, 'SERVO_ANGLE', Blockly.Python.ORDER_ATOMIC) || '';
  var servonum = block.getFieldValue("SERVO_NUM")
  var code = '';
  code = "ServoHelper.setAngle("+servonum+","+servoangel+")\n";
  return code;
};


