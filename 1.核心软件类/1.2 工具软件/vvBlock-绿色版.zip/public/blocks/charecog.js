/**
 * @license Licensed under the Apache License, Version 2.0 (the "License"):
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 * @fileoverview Description.
 */
'use strict';

/** Common HSV hue for all blocks in this category. */
var CHARACTER_HUE = 180;




/** 识别文字 */
Blockly.Blocks['character_recog_result'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(CHARACTER_HUE);
    this.setOutput(true, 'String');
    this.appendDummyInput().appendField('文字识别结果');
    this.setTooltip('获取文字识别结果');
  }
};

Blockly.Python['character_recog_result'] = function(block) {
  //Blockly.Python.definitions_['import_sys'] = 'import sys';
  //Blockly.Python.definitions_['import_characterHelper'] = "sys.path.append('/home/scope/interface/character')\nimport CharacterHelper";
  Blockly.Python.definitions_['import_characterHelper'] = "from interface.character import CharacterHelper";
  var code = 'CharacterHelper.get_character_result()';
  return [code,Blockly.Python.ORDER_MEMBER];
};