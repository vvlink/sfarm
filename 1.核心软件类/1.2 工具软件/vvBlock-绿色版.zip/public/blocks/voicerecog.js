/**
 * @license Licensed under the Apache License, Version 2.0 (the "License"):
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 * @fileoverview Description.
 */
'use strict';

/** Common HSV hue for all blocks in this category. */
var VOICE_RECG_HUE = 300;


/** 设置语速（0-9 5为中速） 默认为5 */ 
Blockly.Blocks['speech_speed'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(VOICE_RECG_HUE);
    this.appendDummyInput()
        .appendField('设置说话语速')
        .appendField(new Blockly.FieldDropdown([
                       ['0', '0'],
                       ['1', '1'],
                       ['2', '2'],
                       ['3', '3'],
                       ['4', '4'],
                       ['5', '5'],
                       ['6', '6'],
                       ['7', '7'],
                       ['8', '8'],
                       ['9', '9'],
                       ['10', '10'],
                       ['11', '11'],
                       ['12', '12'],
                       ['13', '13'],
                       ['14', '14'],
                       ['15', '15']
                     ]),'SPEECH_SPEED');
    this.appendDummyInput()
        .appendField('档');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('设置说话的语速');
  }
};

Blockly.JavaScript['speech_speed'] = function(block) {
  //var speechspeed = Blockly.JavaScript.valueToCode(
  //    block, 'SPEECH_SPEED', Blockly.JavaScript.ORDER_ATOMIC) || '';
  var speechspeed = block.getFieldValue('SPEECH_SPEED');
  
  var code = "speechspeed=" + speechspeed + ";\n";
  //var code = "setvalue(speechspeed)\n";

  return code;
};

Blockly.Python['speech_speed'] = function(block) {
  //var speechspeed = Blockly.Python.valueToCode(
  //    block, 'SPEECH_SPEED', Blockly.Python.ORDER_ATOMIC) || '0';
      
  var speechspeed = block.getFieldValue('SPEECH_SPEED');
  
  //Blockly.Python.definitions_['import_sys'] = 'import sys';
  //Blockly.Python.definitions_['import_voiceHelper'] = "sys.path.append('/home/scope/interface/voice')\nimport VoiceHelper";
  Blockly.Python.definitions_['import_voiceHelper'] = "from interface.voice import VoiceHelper";  
  
  //var code = "speechspeed = " + speechspeed + "\n";
  var code = "VoiceHelper.set_bspd(" + speechspeed +")\n";
  return code;
};


/** 设置音量（0-15，5为中音） 默认为5 */
Blockly.Blocks['speech_volumn'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(VOICE_RECG_HUE);
    this.appendDummyInput()
        .appendField('设置说话音量')
        .appendField(new Blockly.FieldDropdown([
                       ['0', '0'],
                       ['1', '1'],
                       ['2', '2'],
                       ['3', '3'],
                       ['4', '4'],
                       ['5', '5'],
                       ['6', '6'],
                       ['7', '7'],
                       ['8', '8'],
                       ['9', '9'],
                       ['10', '10'],
                       ['11', '11'],
                       ['12', '12'],
                       ['13', '13'],
                       ['14', '14'],
                       ['15', '15']

                     ]),'SPEECH_VOLUMN');
    this.appendDummyInput()
        .appendField('档');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('设置说话的音量');
  }
};

Blockly.Python['speech_volumn'] = function(block) {
  //var speechvolumn = Blockly.Python.valueToCode(
  //    block, 'SPEECH_VOLUMN', Blockly.Python.ORDER_ATOMIC) || '0';
  var speechvolumn = block.getFieldValue('SPEECH_VOLUMN');
  //Blockly.Python.definitions_['import_sys'] = 'import sys';
  //Blockly.Python.definitions_['import_voiceHelper'] = "sys.path.append('/home/scope/interface/voice')\nimport VoiceHelper"; 
  Blockly.Python.definitions_['import_voiceHelper'] = "from interface.voice import VoiceHelper"; 
  var code = "VoiceHelper.set_bvol(" + speechvolumn +")\n";
  //var code = 'speechvolumn = ' + speechvolumn + ';\n';
  return code;
};


/** 设置语调（0-9，5为中音） 默认为5 */
Blockly.Blocks['speech_pit'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(VOICE_RECG_HUE);
    this.appendDummyInput()
        .appendField('设置说话音调')
        .appendField(new Blockly.FieldDropdown([
                       ['0', '0'],
                       ['1', '1'],
                       ['2', '2'],
                       ['3', '3'],
                       ['4', '4'],
                       ['5', '5'],
                       ['6', '6'],
                       ['7', '7'],
                       ['8', '8'],
                       ['9', '9'],
                     ]),'SPEECH_PIT');
    this.appendDummyInput()
        .appendField('档');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('设置说话的音调');
  }
};


Blockly.Python['speech_pit'] = function(block) {
  //var speechvolumn = Blockly.Python.valueToCode(
  //    block, 'SPEECH_VOLUMN', Blockly.Python.ORDER_ATOMIC) || '0';
  var speechpit = block.getFieldValue('SPEECH_PIT');
  //Blockly.Python.definitions_['import_sys'] = 'import sys';
  //Blockly.Python.definitions_['import_voiceHelper'] = "sys.path.append('/home/scope/interface/voice')\nimport VoiceHelper"; 
  Blockly.Python.definitions_['import_voiceHelper'] = "from interface.voice import VoiceHelper"; 
  //var code = "set_bpit(1)\n;
  var code = "VoiceHelper.set_bpit(" + speechpit +")\n";
  return code;
};



/** 设置发音人（0女1男3度逍遥，4度YY） 默认为0 */ 
Blockly.Blocks['speech_agent'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(VOICE_RECG_HUE);
    
    this.appendDummyInput()
        .appendField('设置发音人')
        .appendField(new Blockly.FieldDropdown([
                       ['女音', '0'],
                       ['男音', '1'],
                       ['男音2', '3'],
                       ['小孩', '4']
                     ]),'SPEECH_AGENT');
    this.appendDummyInput()
        .appendField('');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('设置发音人');
  }
};

Blockly.Python['speech_agent'] = function(block) {
  //var speechagent = Blockly.Python.valueToCode(
  //    block, 'SPEECH_AGENT', Blockly.Python.ORDER_ATOMIC) || '0';
  
  var speechagent = block.getFieldValue('SPEECH_AGENT'); 
  //Blockly.Python.definitions_['import_sys'] = 'import sys';
  //Blockly.Python.definitions_['import_voiceHelper'] = "sys.path.append('/home/scope/interface/voice')\nimport VoiceHelper"; 
  Blockly.Python.definitions_['import_voiceHelper'] = "from interface.voice import VoiceHelper"; 
  var code = "VoiceHelper.set_bper(" + speechagent +")\n";
  return code;
};


/** 说（Text）*/
Blockly.Blocks['bdspeech'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(VOICE_RECG_HUE);
    this.appendDummyInput()
        .appendField('说');
    this.appendValueInput('SPEECH_TEXT', 'String')
        .setCheck('String');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('设置说话的内容');
  }
};

Blockly.Python['bdspeech'] = function(block) {
  //Blockly.Python.definitions_['import_sys'] = 'import sys';
  //Blockly.Python.definitions_['import_voiceHelper'] = "sys.path.append('/home/scope/interface/voice')\nimport VoiceHelper"; 
  Blockly.Python.definitions_['import_voiceHelper'] = "from interface.voice import VoiceHelper"; 
  var speechtext = Blockly.Python.valueToCode(block, 'SPEECH_TEXT', Blockly.Python.ORDER_ATOMIC);
  var code = "VoiceHelper.say("+speechtext+")\n";
  return code;
};




/** 识别语音 */
Blockly.Blocks['recog_result'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(VOICE_RECG_HUE);
    this.setOutput(true, 'String')
    this.appendDummyInput().appendField('语音识别结果');
    this.setTooltip('获取语音识别的结果');
  }
};

Blockly.Python['recog_result'] = function(block) {
  //Blockly.Python.definitions_['import_sys'] = 'import sys';
  //Blockly.Python.definitions_['import_voiceHelper'] = "sys.path.append('/home/scope/interface/voice')\nimport VoiceHelper"; 
  Blockly.Python.definitions_['import_voiceHelper'] = "from interface.voice import VoiceHelper"; 
  var code = 'VoiceHelper.get_voice_result()';
  return [code,Blockly.Python.ORDER_MEMBER];
};


/** 识别语音 */
Blockly.Blocks['set_auto_play_hint'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(VOICE_RECG_HUE);
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.appendDummyInput().appendField('播放提示音')
        .appendField(new Blockly.FieldDropdown([
                       ['是', 'True'],
                       ['否', 'False'],
                     ]),'AUTO_PLAY_HINT');
    this.setTooltip('禁用获取语音结果时的提示音');
  }
};

Blockly.Python['set_auto_play_hint'] = function(block) {
  //Blockly.Python.definitions_['import_sys'] = 'import sys';
  //Blockly.Python.definitions_['import_voiceHelper'] = "sys.path.append('/home/scope/interface/voice')\nimport VoiceHelper"; 
  Blockly.Python.definitions_['import_voiceHelper'] = "from interface.voice import VoiceHelper"; 
  var auto_play_hint = block.getFieldValue('AUTO_PLAY_HINT'); 
  var code = 'VoiceHelper.set_auto_play_hint('+auto_play_hint+')\n';
  return code
};




