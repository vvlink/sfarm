document.write("<script src='js/FileSaver.js'></script>")
document.write("<script src='js/jquery.min.js'></script>")

blockFileSave = function() {
 var xml = Blockly.Xml.workspaceToDom(Bgpio.workspace);
 var xml_text = Blockly.Xml.domToText(xml);
 console.log("saving blob");
 var blob = new Blob([xml_text], {type: 'text/xml;charset=utf-8'});
 saveAs(blob,'temp.xml');
};

blockFileLoad = function() {
 //alert('111111');
 var xml_text = localStorage.getItem('C:\Users\10141\Downloads\2.xml');
 if (xml_text)
 {
  var xml = Blockly.Xml.textToDom(xml_text);
  Blockly.Xml.domToWorkspace(xml,Bgpio.workspace);
 }
};    