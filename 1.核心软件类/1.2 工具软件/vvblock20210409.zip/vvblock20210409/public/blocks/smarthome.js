/**
 * @license Licensed under the Apache License, Version 2.0 (the "License"):
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 * @fileoverview Description.
 */
'use strict';

/** Common HSV hue for all blocks in this category. */
var PLAY_HUE = 90;


/** 设置播放故事 */ 
Blockly.Blocks['play_tv'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(PLAY_HUE);
    this.appendDummyInput()
        .appendField('播放电视')
        .appendField(new Blockly.FieldDropdown([
                       ['开', '1'],
                       ['关', '0']
                     ]),'TV_STATE')
        .appendField(new Blockly.FieldDropdown([
                       // ['电视剧', '0'],
                       // ['动画电影', '1'],
                       // ['动作片', '2'],
                       // ['科幻', '3'],
                       // ['战争片', '4'],
                       // ['随机', '6']

                       ['电视剧', '电视剧'],
                       ['动画电影', '动画电影'],
                       ['动作片', '动作片'],
                       ['科幻', '科幻'],
                       ['战争片', '战争片'],
                       ['随机', '随机']
                     ]),'TV_TYPE');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('播放电视');
  }
};


Blockly.Python['play_tv'] = function(block) {

  var tv_type = block.getFieldValue('TV_TYPE');
  var tv_state = block.getFieldValue('TV_STATE');
  Blockly.Python.definitions_['import_sys'] = 'import sys';
  Blockly.Python.definitions_['import_ble_sender'] = "sys.path.append('/home/scope/interface')\nimport blesender";
  
  var code = 'blesender.control_tv('+tv_state+',"'+tv_type+'")\n';
  return code;
};


/** 设置播放音乐 */ 
Blockly.Blocks['play_wbl'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(PLAY_HUE);
    this.appendDummyInput()
        .appendField('微波炉')
        .appendField(new Blockly.FieldDropdown([
                       ['开启', '1'],
                       ['关闭', '0']
                     ]),'MUSIC_NAME');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('微波炉');
  }
};


Blockly.Python['play_wbl'] = function(block) {

  var musicname = block.getFieldValue('MUSIC_NAME');
  Blockly.Python.definitions_['import_sys'] = 'import sys';
  Blockly.Python.definitions_['import_ble_sender'] = "sys.path.append('/home/scope/interface/resources')\nimport ResourcePlayer";
  var code = "ResourcePlayer.play('"+musicname+"',is_music=True)\n";
  return code;
};





