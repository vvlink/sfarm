'use strict';

var IMAGE_HUE = 210;



/** 识别语音 */
Blockly.Blocks['image_recog_result'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(IMAGE_HUE);
    this.setOutput(true, 'String');
    this.appendDummyInput().appendField('图像识别结果');
    this.setTooltip('获取图像识别结果');
  }
};

Blockly.Python['image_recog_result'] = function(block) {
  //Blockly.Python.definitions_['import_sys'] = 'import sys';
  //Blockly.Python.definitions_['import_photoHelper'] = "sys.path.append('/home/scope/interface/photo')\nimport PhotoHelper";
  Blockly.Python.definitions_['import_photoHelper'] = "from interface.photo import PhotoHelper";
  var code = 'PhotoHelper.get_photo_result()';
  return [code,Blockly.Python.ORDER_MEMBER];
};


/** 百度动物识别 */
Blockly.Blocks['animal_recog_result'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(IMAGE_HUE);
    this.setOutput(true, 'String');
    this.appendDummyInput().appendField('动物识别结果');
    this.setTooltip('获取动物识别结果');
  }
};

Blockly.Python['animal_recog_result'] = function(block) {
 
  Blockly.Python.definitions_['import_bdphotodetect'] = "from interface.baiduapi.photo import bdphotodetect";
  var code = 'bdphotodetect.get_animal_result()';
  return [code,Blockly.Python.ORDER_MEMBER];
};



/** 百度植物识别 */
Blockly.Blocks['plants_recog_result'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(IMAGE_HUE);
    this.setOutput(true, 'String');
    this.appendDummyInput().appendField('植物识别结果');
    this.setTooltip('获取植物识别结果');
  }
};

Blockly.Python['plants_recog_result'] = function(block) {
 
  Blockly.Python.definitions_['import_bdphotodetect'] = "from interface.baiduapi.photo import bdphotodetect";
  var code = 'bdphotodetect.get_plants_result()';
  return [code,Blockly.Python.ORDER_MEMBER];
};


/** 百度车型识别 */
Blockly.Blocks['car_type_recog_result'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(IMAGE_HUE);
    this.setOutput(true, 'String');
    this.appendDummyInput().appendField('车型识别结果');
    this.setTooltip('获取车型识别结果');
  }
};

Blockly.Python['car_type_recog_result'] = function(block) {
 
  Blockly.Python.definitions_['import_bdphotodetect'] = "from interface.baiduapi.photo import bdphotodetect";
  var code = 'bdphotodetect.get_car_type_result()';
  return [code,Blockly.Python.ORDER_MEMBER];
};
