'use strict';
var FACE_HUE = 65;

Blockly.Blocks['set_face_name'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(FACE_HUE);
    this.appendValueInput(
          'FACE_NAME', 'String')
        .setCheck('String')
        .appendField('设置人物名称');
    this.appendDummyInput();
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('设置采集数据人的姓名');
  }
};

Blockly.JavaScript['set_face_name'] = function(block) {
  var facename = Blockly.JavaScript.valueToCode(
      block, 'FACE_NAME', Blockly.JavaScript.ORDER_ATOMIC) || '';

  var code = 'FaceHelper.set_user_name(" + facename +")\n';
  return code;
};

Blockly.Python['set_face_name'] = function(block) {
  var facename = Blockly.Python.valueToCode(
      block, 'FACE_NAME', Blockly.Python.ORDER_ATOMIC) || '';
  //Blockly.Python.definitions_['import_sys'] = "import sys";
  //Blockly.Python.definitions_['import_faceHelper'] = "sys.path.append('/home/scope/interface/face')\nimport FaceHelper";  
  Blockly.Python.definitions_['import_faceHelper'] = "from interface.face import FaceHelper";
  var code = "FaceHelper.set_user_name(" + facename +")\n";
  return code;
};


Blockly.Blocks['remove_face_data'] = {

    init: function() {
      this.setHelpUrl('');
      this.setColour(FACE_HUE);
      this.appendDummyInput()
          .appendField('删除人脸数据')
      this.setTooltip('删除所有录入的人脸数据')

    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};

Blockly.Python['remove_face_data'] = function(block) {
    //Blockly.Python.definitions_['import_os'] = 'import os';
   
    //var code = 
    //"root_path='/home/scope/interface/face/datasets'\n" +
    //"for root,dirs,files in os.walk(root_path):\n" +
    //"  for sub in dirs:\n" +
    //"      cpath=os.path.join(root_path,sub)"+
    //"      for cfile in os.listdir(cpath):"+
    //"        os.remove(os.path.join(cpath,cfile))"+
    //"      os.rmdir(os.path.join(root_path,sub))\n" 
	Blockly.Python.definitions_['import_faceHelper'] = "from interface.face import FaceHelper";
    var code = "FaceHelper.clearFaceData()\n";
    return code;
};


Blockly.Blocks['face_reg_bool'] = {

    init: function() {
      this.setHelpUrl('');
      this.setColour(FACE_HUE);
      this.setOutput(true,'Boolean')
      this.appendDummyInput()
          .appendField('获取人脸数据')
      this.setTooltip('获取单次人脸数据采集的结果')
          // .appendField(new Blockly.FieldDropdown([
          //                ['True', '1'],
          //                ['False', '0']
          //              ]),'FACE_RECOG_BOOL');
  }
};

Blockly.Python['face_reg_bool'] = function(block) {
    //Blockly.Python.definitions_['import_sys'] = 'import sys';
    //Blockly.Python.definitions_['import_faceHelper'] = "sys.path.append('/home/scope/interface/face')\nimport FaceHelper";
    Blockly.Python.definitions_['import_faceHelper'] = "from interface.face import FaceHelper";
	var code = "FaceHelper.get_photo_issuccess()";
    return [code,Blockly.Python.ORDER_MEMBER];
};



Blockly.Blocks['reg_face_name'] = {
   init: function() {
    this.setHelpUrl('');
    this.setColour(FACE_HUE);
    this.setOutput(true, 'String')
    this.appendDummyInput().appendField('人脸识别结果');
    this.setTooltip('获取单次人脸数据识别的结果');
  }
};

Blockly.Python['reg_face_name'] = function(block) {
  //Blockly.Python.definitions_['import_sys'] = "import sys";
  //Blockly.Python.definitions_['import_faceHelper'] = "sys.path.append('/home/scope/interface/face')\nimport FaceHelper";
  Blockly.Python.definitions_['import_faceHelper'] = "from interface.face import FaceHelper";
  var code = "FaceHelper.get_photo_result()";
  return [code,Blockly.Python.ORDER_MEMBER];
};












