/**
 * @license Licensed under the Apache License, Version 2.0 (the "License"):
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 * @fileoverview Description.
 */
'use strict';

/** Common HSV hue for all blocks in this category. */
var SIOT_HUE = 350;


Blockly.Blocks['siot_init'] = {
  init: function() {
    this.setColour(SIOT_HUE);
	this.appendDummyInput()
        .appendField('创建SIoT连接');
    this.appendValueInput('IPADDRESS')
    .setCheck("String")
    .appendField("IP地址");
    this.appendValueInput('USERNAME')
    .setCheck("String")
    .appendField("用户名");
    this.appendValueInput('PASSWORD')
    .setCheck("String")
    .appendField('密码');
  
    //this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip("创建SIoT服务器");
  }
};

Blockly.Python['siot_init']=function(block){
    Blockly.Python.definitions_['import_siot'] = 'import siot';
	Blockly.Python.definitions_['siot_state'] = '_siot_connected=False';
    var ipaddress = Blockly.Python.valueToCode(block, 'IPADDRESS', Blockly.JavaScript.ORDER_ATOMIC) ;
	var username = Blockly.Python.valueToCode(block, 'USERNAME', Blockly.JavaScript.ORDER_ATOMIC) ;
	var password = Blockly.Python.valueToCode(block, 'PASSWORD', Blockly.JavaScript.ORDER_ATOMIC) ;
	
    var code = "siot.init(\'\',"+ipaddress+",user="+username+",password="+password+")\n"+
	'siot.connect()\n'+
	'_siot_connected=True\n';
	return code;
};



Blockly.Blocks['siot_connect_state'] = {
    init: function() {
      this.setHelpUrl('');
      this.setColour(SIOT_HUE);
      this.setOutput(true,'Boolean')
      this.appendDummyInput()
          .appendField('SIoT连接成功?')
      this.setTooltip('获取SIoT连接状态')
  }
};

Blockly.Python['siot_connect_state'] = function(block) {
    Blockly.Python.definitions_['import_siot'] = 'import siot';
	Blockly.Python.definitions_['siot_state'] = '_siot_connected=False';
    var code = "_siot_connected";
    return [code,Blockly.Python.ORDER_MEMBER];
};

Blockly.Blocks['siot_disconnect'] = {
    init: function() {
      this.setHelpUrl('');
      this.setColour(SIOT_HUE);
      this.appendDummyInput()
          .appendField('SIoT断开连接')
	  this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setTooltip('断开SIoT连接')
  }
};

Blockly.Python['siot_disconnect'] = function(block) {
    Blockly.Python.definitions_['import_siot'] = 'import siot';
	Blockly.Python.definitions_['siot_state'] = '_siot_connected=False';
    var code = "siot.stop()\n_siot_connected=False \n";
    return code;
};

 
 
Blockly.Blocks['siot_send_msg'] = {
  init: function() {
    this.setColour(SIOT_HUE);
	this.appendDummyInput()
        .appendField('SIoT发送消息');
    this.appendValueInput('MESSAGE')
    .setCheck("String");
	this.appendDummyInput().appendField("到主题");
    this.appendValueInput('TOPIC')
    .setCheck("String")
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip("发送消息到SIoT服务器");
  }
};


Blockly.Python['siot_send_msg'] = function(block) {
    Blockly.Python.definitions_['import_siot'] = 'import siot';
	var message = Blockly.Python.valueToCode(block, 'MESSAGE', Blockly.JavaScript.ORDER_ATOMIC) ;
	var topic = Blockly.Python.valueToCode(block, 'TOPIC', Blockly.JavaScript.ORDER_ATOMIC) ;
    var code = "siot.publish("+topic+","+message+")\n";
    return code
};


/*
Blockly.Blocks['siot_subscribe_topic'] = {
  init: function() {
    this.setColour(SIOT_HUE);
	this.appendDummyInput()
        .appendField('订阅SIoT主题');
    this.appendValueInput('TOPIC')
    .setCheck("String");
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip("用于订阅SIoT主题");
  }
};
*/
Blockly.Blocks["siot_subscribe_topic"]={
    init:function(){
		this.setColour(SIOT_HUE);
		this.itemCount_=1;
		this.updateShape_();
		this.setPreviousStatement(true);
      this.setNextStatement(true);
		this.setMutator(new Blockly.Mutator(["text_create_join_item"]));
		this.setTooltip("订阅SIoT主题")
	},
	
	mutationToDom:function(){
		var a=document.createElement("mutation");
		a.setAttribute("items",this.itemCount_);
		return a
	},
	domToMutation:function(a){
		this.itemCount_=parseInt(a.getAttribute("items"),10);
		this.updateShape_()
},
	decompose:function(a){
		var b=Blockly.Block.obtain(a,"text_create_join_container");
		b.initSvg();
		for(var c=b.getInput("STACK").connection,d=0;d<this.itemCount_;d++){
			var e=Blockly.Block.obtain(a,"text_create_join_item");
			e.initSvg();
			c.connect(e.previousConnection);
			c=e.nextConnection
		}
		return b
	},
	compose:function(a){
		var b=a.getInputTargetBlock("STACK");
		for(a=[];b;)
		   a.push(b.valueConnection_),b=b.nextConnection&&b.nextConnection.targetBlock();
		this.itemCount_=a.length;
		this.updateShape_();
		for(b=0;b<this.itemCount_;b++)
		   a[b]&&this.getInput("ADD"+b).connection.connect(a[b])
	},
	saveConnections:function(a){
		a=a.getInputTargetBlock("STACK");
		for(var b=0;a;){
			var c=this.getInput("ADD"+b);
		a.valueConnection_=c&&c.connection.targetConnection;
		b++;
		a=a.nextConnection&&a.nextConnection.targetBlock()
	}
},
	updateShape_:function(){
		if(this.getInput("EMPTY"))
			this.removeInput("EMPTY");
		else for(var a=0;this.getInput("ADD"+a);)
			this.removeInput("ADD"+a),a++;
		if(0==this.itemCount_)
			this.appendDummyInput("EMPTY").appendField(this.newQuote_(!0)).appendField(this.newQuote_(!1));
		else for(a=0;a<this.itemCount_;a++){
			var b=this.appendValueInput("ADD"+a);
			0==a&&b.appendField("订阅SIoT主题")
		}
},
	newQuote_:Blockly.Blocks.text.newQuote_
};


Blockly.Blocks['text_create_join_item'] = {
  /**
   * Mutator bolck for adding items.
   * @this Blockly.Block
   */
   init: function() {
    this.setColour(SIOT_HUE);
    this.appendDummyInput()
    .appendField("主题");
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip("主题");
    this.contextMenu = false;
  }
};


Blockly.Blocks.text_create_join_container={
	init:function(){
		this.setColour(SIOT_HUE);
		this.appendDummyInput().appendField("订阅主题");
		this.appendStatementInput("STACK");
		this.setTooltip("订阅主题");
		this.contextMenu=!1;
	}
};


Blockly.Python['siot_subscribe_topic'] = function(block) {
    Blockly.Python.definitions_['import_siot'] = 'import siot';
	Blockly.Python.definitions_['siot_subcribe']='topic_msg_map={}\n'+
	'def on_topic_subscribe(client,userdata,msg):\n'+
	'  global topic_msg_map\n'+
	'  topic_msg_map[str(msg.topic)]=str(msg.payload.decode())\n';
	
	
	var code = new Array(this.itemCount_);
    for (var n = 0; n < this.itemCount_; n++) {
		code[n] = Blockly.Python.valueToCode(this, 'ADD' + n,
		Blockly.Python.ORDER_NONE) || '';
	}
    var code1 = '';
    for (var n = 0; n < this.itemCount_; n++) {	  
	  if(code[n]!='')
        code1 += "siot.subscribe("+code[n]+",on_topic_subscribe)\n";		
    }
	var topic = Blockly.Python.valueToCode(block, 'TOPIC', Blockly.JavaScript.ORDER_ATOMIC) ;
    code1 += "siot.loop()\n";
    return code1
};



Blockly.Blocks['siot_read_msg'] = {
  init: function() {
    this.setColour(SIOT_HUE);
	this.appendDummyInput()
        .appendField('从SIoT主题');
    this.appendValueInput('TOPIC')
    .setCheck("String");
	this.appendDummyInput().appendField("获取消息");
	this.setOutput(true, 'String')
    this.setTooltip("从SIoT主题读取消息");
  }
};


Blockly.Python['siot_read_msg'] = function(block) {
    Blockly.Python.definitions_['import_siot'] = 'import siot';
	Blockly.Python.definitions_['siot_read_topice_msg']=
	'def on_topic_read(topic):\n'+
	'  global topic_msg_map\n'+
	'  result=topic_msg_map.get(topic,None)\n'+
	'  if result:\n'+
    '     del topic_msg_map[topic]\n'+
	'  return result \n';
	var topic = Blockly.Python.valueToCode(block, 'TOPIC', Blockly.JavaScript.ORDER_ATOMIC) ;
    var code = "on_topic_read("+topic+")";
    return [code,Blockly.Python.ORDER_MEMBER];
};




