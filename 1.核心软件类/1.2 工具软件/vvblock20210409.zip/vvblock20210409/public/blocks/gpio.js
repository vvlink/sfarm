'use strict';

var GPIO_HUE = 30;

var pin_array=[['0', 'Pin.D0'],  
			   ['1', 'Pin.D1'],
			   ['2', 'Pin.D2'],
			   ['3', 'Pin.D3'],
			   ['4', 'Pin.D4'],
			   ['5', 'Pin.D5'],
			   ['6', 'Pin.D6'],
			   ['7', 'Pin.D7'],
			   ['8', 'Pin.D8'],
			   ['9', 'Pin.D9'],
			   ['10', 'Pin.D10'],
			   ['11', 'Pin.D11'],
			   ['12', 'Pin.D12'],
			   ['13', 'Pin.D13'],
			   ['A0', 'Pin.A0'],
			   ['A1', 'Pin.A1'],
			   ['A2', 'Pin.A2'],
			   ['A3', 'Pin.A3'],
			   ['A4', 'Pin.A4'],
			   ['A5', 'Pin.A5']];

var analog_pin=[['A0', 'Pin.A0'],
			   ['A1', 'Pin.A1'],
			   ['A2', 'Pin.A2'],
			   ['A3', 'Pin.A3'],
			   ['A4', 'Pin.A4'],
			   ['A5', 'Pin.A5']];	

var temp_array=[['DHT11',"DHT11"],
				['DHT22',"DHT22"]
]	

var temp_value=[['获取温度',"temp_c()"],
				['获取湿度',"humidity()"]
]		   
			   
			   
function get_pin_value(pin){
   if(pin>19){
	  pin=0;
   }
   pin=parseInt(pin);
   if(pin<=13){
      return "Pin.D"+pin
   }
   else if(pin>=14 && pin <=19){
	  var num=5+pin-19;
      return "Pin.A"+num;
   }	  
   return 0
}
     


/**获取触摸板状态*/
Blockly.Blocks['get_button_status'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(GPIO_HUE);
    this.appendDummyInput()
        .appendField('按键传感器')
    .appendField(new Blockly.FieldDropdown(pin_array) ,'BUTTON_PIN');		

    this.appendDummyInput()
        .appendField('是否按下')
    this.setInputsInline(true);
    this.setOutput(true, 'Boolean')
    this.setTooltip('用于获取按键控制器的状态');
  }
};

Blockly.Python['get_button_status'] = function(block) {
  var buttonpin =block.getFieldValue('BUTTON_PIN');
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  
  var code = "Pin("+buttonpin+",Pin.IN).read_digital()";
  return [code,Blockly.Python.ORDER_MEMBER];
};



/**控制蜂鸣器*/
Blockly.Blocks['buzzer_on'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(GPIO_HUE);
    this.appendDummyInput()
        .appendField('蜂鸣器')
        .appendField(new Blockly.FieldDropdown(pin_array) ,'BUTTON_PIN');	
    this.appendDummyInput()
        .appendField('震动')
    this.appendDummyInput()
        .appendField(new Blockly.FieldDropdown([
                       ['开', '1'],
                       ['关', '0']
                     ]),'BUZZER_STATUS');

    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('用于开启或者关闭蜂鸣器');
  }
};

Blockly.Python['buzzer_on'] = function(block) {
  var buzzerstatus = block.getFieldValue('BUZZER_STATUS');
  var pin =block.getFieldValue('BUTTON_PIN');
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  
 

  var code ="";
  var on="False";
  if(buzzerstatus=="1") {
     code = "Pin("+pin+",Pin.OUT).write_digital(1)\n";
  }else{
	  code = "Pin("+pin+",Pin.OUT).write_digital(0)\n";
  }

  return code;
};


/**获取触摸板状态*/
Blockly.Blocks['get_touch_status'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(GPIO_HUE);
    this.appendDummyInput()
        .appendField('触摸传感器')
        .appendField(new Blockly.FieldDropdown(pin_array) ,'BUTTON_PIN');	
    this.appendDummyInput()
        .appendField('是否正在触摸')
    this.setInputsInline(true);
    this.setOutput(true, 'Boolean')
    this.setTooltip('用于获取触摸传感器的状态');
  }
};

Blockly.Python['get_touch_status'] = function(block) {
  var buttonpin =block.getFieldValue('BUTTON_PIN');
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  
  var code = "Pin("+buttonpin+",Pin.IN).read_digital()";
  return [code,Blockly.Python.ORDER_MEMBER];
};





/**获取超声波距离*/
Blockly.Blocks['get_sensor_distance'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(GPIO_HUE);
    this.appendDummyInput()
        .appendField('获取SR04_urm10超声波感应距离');   
     this.appendDummyInput()
        .appendField('TrigPin');     
     this.appendValueInput('trig_pin', 'Number')
        .setCheck('Number');
     this.appendDummyInput()
        .appendField('EchoPin');    
      this.appendValueInput('echo_pin', 'Number')
        .setCheck('Number');       
    this.setInputsInline(true);
    this.setOutput(true, 'Number')
    this.setTooltip('用于获取连接设备的超声波后返回的距离');
  }
};

Blockly.Python['get_sensor_distance'] = function(block) {
  
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  
  var trigpin = Blockly.Python.valueToCode(
      block, 'trig_pin', Blockly.Python.ORDER_ATOMIC) || '';
  var echopin = Blockly.Python.valueToCode(
      block, 'echo_pin', Blockly.Python.ORDER_ATOMIC) || '';
  trigpin=get_pin_value(trigpin);
  echopin=get_pin_value(echopin);  
  var code = "SR04_URM10(Pin("+trigpin+"),Pin("+echopin+")).distance_cm() ";
  return [code,Blockly.Python.ORDER_MEMBER];
};


/**设置LED灯开关*/
Blockly.Blocks['set_led'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(GPIO_HUE);
    this.appendDummyInput()
        .appendField('设置LED')
        .appendField(new Blockly.FieldDropdown(pin_array) ,'LED_PIN');	
    this.appendDummyInput().appendField('状态')
        .appendField(new Blockly.FieldDropdown([
                       ['开', '1'],
                       ['关', '0']
                     ]),'LED_STATUS');

    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('用于设置连接设备指定pin号的led灯开关');
  }
};

Blockly.Python['set_led'] = function(block) {
  var ledstatus = block.getFieldValue('LED_STATUS');
  var ledpin = block.getFieldValue('LED_PIN');
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  

  var code ="";
  var on="False";
  if(ledstatus=="1") {
     code = "Pin("+ledpin+",Pin.OUT).write_digital(1)\n";
  }else{
	 code = "Pin("+ledpin+",Pin.OUT).write_digital(0)\n";
  }
  return code;
};


/**设置RGB灯开关*/
Blockly.Blocks['set_rgb'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(GPIO_HUE);
    this.appendDummyInput()
        .appendField('设置RGB显示亮度红色')
    this.appendValueInput('RGB_R_PIN', 'Number')
        .setCheck('Number');
    this.appendDummyInput()
        .appendField('绿色')
    this.appendValueInput('RGB_G_PIN', 'Number')
        .setCheck('Number');
    this.appendDummyInput()
        .appendField('蓝色')
    this.appendValueInput('RGB_B_PIN', 'Number')
        .setCheck('Number');
    this.appendDummyInput()
        .appendField('红色')
        .appendField(new Blockly.FieldDropdown([
                       ['开', '1'],
                       ['关', '0']
                     ]),'RGB_R_STATUS');
    this.appendDummyInput()
        .appendField('绿色')
        .appendField(new Blockly.FieldDropdown([
                       ['开', '1'],
                       ['关', '0']
                     ]),'RGB_G_STATUS');
    this.appendDummyInput()
        .appendField('蓝色')
        .appendField(new Blockly.FieldDropdown([
                       ['开', '1'],
                       ['关', '0']
                     ]),'RGB_B_STATUS');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('用于设置连接设备rgb灯的显示与百分比');
  }
};

Blockly.Python['set_rgb'] = function(block) {
  var rgbrpin = Blockly.Python.valueToCode(
      block, 'RGB_R_PIN', Blockly.Python.ORDER_ATOMIC) || '';
  var rgbgpin = Blockly.Python.valueToCode(
      block, 'RGB_G_PIN', Blockly.Python.ORDER_ATOMIC) || '';
  var rgbbpin = Blockly.Python.valueToCode(
      block, 'RGB_B_PIN', Blockly.Python.ORDER_ATOMIC) || '';    
      
  var rgbrstatus = block.getFieldValue('RGB_R_STATUS');
  var rgbgstatus = block.getFieldValue('RGB_G_STATUS');
  var rgbbstatus = block.getFieldValue('RGB_B_STATUS');
  
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  
  var code ="";
  var on="False";
  rgbrpin=get_pin_value(rgbrpin);
  rgbgpin=get_pin_value(rgbgpin);
  rgbbpin=get_pin_value(rgbbpin);
  if(rgbrstatus=="1") {
     code = "Pin("+rgbrpin+",Pin.OUT).write_digital(1)\n";
  }else{
	 code = "Pin("+rgbrpin+",Pin.OUT).write_digital(0)\n";
  }
  if(rgbgstatus=="1") {
     code += "Pin("+rgbgpin+",Pin.OUT).write_digital(1)\n";
  }else{
	 code += "Pin("+rgbgpin+",Pin.OUT).write_digital(0)\n";
  }
  
  if(rgbbstatus=="1") {
     code += "Pin("+rgbbpin+",Pin.OUT).write_digital(1)\n";
  }else{
	 code += "Pin("+rgbbpin+",Pin.OUT).write_digital(0)\n";
  }
  
  
  return code;
};


/**获取光敏传感器返回的数值*/
Blockly.Blocks['get_light_sensor'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(GPIO_HUE);
    this.appendDummyInput()
        .appendField('获取光敏传感器数值')
        .appendField(new Blockly.FieldDropdown(analog_pin) ,'LIGHT_PIN');    
    this.setInputsInline(true);
    this.setOutput(true, 'Number')
    this.setTooltip('用于获取连接设备的光敏传感器返回的数值');
  }
};

Blockly.Python['get_light_sensor'] = function(block) {
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  	
  var pin = block.getFieldValue("LIGHT_PIN");
  var code = "Pin("+pin+",Pin.ANALOG).read_analog()";
  return [code,Blockly.Python.ORDER_MEMBER];
};





/** 设置舵机角度 */ 
Blockly.Blocks['set_servo_angle'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(GPIO_HUE);
    this.appendDummyInput()
        .appendField('设置9g舵机')
    this.appendValueInput('SERVO_NUM', 'Number')
        .setCheck('Number');
    this.appendDummyInput()
        .appendField('角度');    
    this.appendValueInput('SERVO_ANGLE', 'Number')
        .setCheck('Number');
    this.appendDummyInput()
        .appendField('度');     
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('设置连接设备舵机的转向角度');
  }
};

Blockly.Python['set_servo_angle'] = function(block) {
  var servoangel = Blockly.Python.valueToCode(
      block, 'SERVO_ANGLE', Blockly.Python.ORDER_ATOMIC) || '';
  var servonum = Blockly.Python.valueToCode(
      block, 'SERVO_NUM', Blockly.Python.ORDER_ATOMIC) || '';
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  
  servonum=get_pin_value(servonum);
  var code = "Servo(Pin("+servonum+")).write_angle("+servoangel	+")\n";
  return code;
};


//获取到的温度
Blockly.Blocks['get_temperatur'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(GPIO_HUE);
    this.appendDummyInput().appendField('获取DHT11传感器的温度')
    this.appendValueInput('PIN', 'Number')
        .setCheck('Number');
    this.setInputsInline(true);
    this.setOutput(true,"Number")
    this.setTooltip('获取连接设备返回的温度');
  }
};


Blockly.Python['get_temperatur'] = function(block) {
  Blockly.Python.definitions_['import_sys'] = "import sys";
  Blockly.Python.definitions_['import_tempHumHelper'] = "sys.path.append('/home/scope/interface/gpio')\nimport TempHumHelper";

  var code = ""; 
  var pin = Blockly.Python.valueToCode(
      block, 'PIN', Blockly.Python.ORDER_ATOMIC) || '';
  code = "TempHumHelper.getTemperature("+pin+")";
  return [code,Blockly.Python.ORDER_MEMBER];
};


//获取到的湿度
Blockly.Blocks['dht_read'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(GPIO_HUE);
    this.appendDummyInput()
        .appendField(new Blockly.FieldDropdown(temp_array),'TEMP_TYPE');
	this.appendDummyInput().appendField('引脚')	
	.appendField(new Blockly.FieldDropdown(pin_array),'PIN');	
	this.appendDummyInput().appendField('  ')	
	.appendField(new Blockly.FieldDropdown(temp_value),'TEMP_VALUE');
    this.setInputsInline(true);
    this.setOutput(true,"Number")
    this.setTooltip('获取连接设备返回的湿度');
  }
};


Blockly.Python['dht_read'] = function(block) {
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  
  var type =block.getFieldValue("TEMP_TYPE");
  var pin =block.getFieldValue("PIN");
  var value =block.getFieldValue("TEMP_VALUE");
  var code = type+"(Pin("+pin+"))."+value;
  return [code,Blockly.Python.ORDER_MEMBER];
};