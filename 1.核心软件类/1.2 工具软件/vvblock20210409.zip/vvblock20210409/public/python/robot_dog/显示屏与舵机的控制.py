﻿import sys
from time import sleep

a = None

sys.path.append('/home/pi/aicomer/voice')
import VoiceHelper

sys.path.append('/home/pi/aicomer/tftdisplay')
import EyeHelper

sys.path.append('/home/pi/aicomer/gpio')
import ServoHelper


a = True
VoiceHelper.set_bspd(3)
VoiceHelper.set_bvol(8)
VoiceHelper.set_bpit(6)
VoiceHelper.set_bper(4)
VoiceHelper.say('你好')
ServoHelper.setAngle(2,5)
ServoHelper.setAngle(1,5)
sleep(1.5);
ServoHelper.setAngle(1,90)
ServoHelper.setAngle(2,90)
