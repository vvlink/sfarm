import sys
sys.path.append('/home/pi/aicomer/voice')
import VoiceHelper


sys.path.append('/home/pi/aicomer/character')
import CharacterHelper


openstr=['字','认','什么']
def handlresult():
    result=VoiceHelper.get_voice_result()
    if(not result is None):
          for key in openstr:
              if(key in result):
                  result=CharacterHelper.get_character_result()
                  VoiceHelper.say(result)  
#语音识别 获取温度
while True:
      handlresult()
    
                  




