import sys
from time import sleep

sys.path.append('/home/pi/aicomer/voice')
import VoiceHelper

sys.path.append('/home/pi/aicomer/gpio')
import DCHelper


result=None
openstr=['热','开风扇']
closestr=['冷','关风扇']


#语音识别 开启马达
while True:
      result=VoiceHelper.get_voice_result()
      if(not result is None):
          for key in openstr:
              if(key in result):
                  DCHelper.MotorManager().getMotor(3).setSpeed(100).run(DCHelper.FORWARD)
                  break
          for key in closestr:
              if(key in result):
                  DCHelper.MotorManager().getMotor(3).run(DCHelper.RELEASE)
                  break
            




