/**
 * @license Licensed under the Apache License, Version 2.0 (the "License"):
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 * @fileoverview Description.
 */
'use strict';

/** Common HSV hue for all blocks in this category. */
var PLAY_HUE = 75;


/** 设置播放故事 */ 
Blockly.Blocks['play_story'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(PLAY_HUE);
    this.appendDummyInput()
        .appendField('播放故事')
        .appendField(new Blockly.FieldDropdown([
                       ['白雪公主', '白雪公主.mp3'],
                       ['龟兔赛跑', '龟兔赛跑.mp3'],
                       ['金斧头银斧头', '银斧头.mp3'],
                       ['狼来了', '狼来了.mp3'],
                       ['小猴子下山', '小猴子下山.mp3'],
                       ['小红帽', '小红帽.mp3'],
                     ]),'STORY_NAME');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('播放故事');
  }
};


Blockly.Python['play_story'] = function(block) {

  var storyname = block.getFieldValue('STORY_NAME');
  Blockly.Python.definitions_['import_sys'] = 'import sys';
  Blockly.Python.definitions_['import_resource_player'] = "sys.path.append('/home/scope/interface/resources')\nimport ResourcePlayer";
  var code = "ResourcePlayer.play('"+storyname+"',is_story=True)\n";
  return code;
};


/** 设置播放音乐 */ 
Blockly.Blocks['play_music'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(PLAY_HUE);
    this.appendDummyInput()
        .appendField('播放音乐')
        .appendField(new Blockly.FieldDropdown([
                       ['妈妈的吻', '妈妈的吻.mp3'],
                       ['歌唱二小放牛郎', '歌唱二小放牛郎.mp3'],
                       ['恭喜恭喜', '恭喜恭喜.mp3'],
                       ['卖报歌', '卖报歌.mp3']
                     ]),'MUSIC_NAME');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('播放音乐');
  }
};


Blockly.Python['play_music'] = function(block) {

  var musicname = block.getFieldValue('MUSIC_NAME');
  Blockly.Python.definitions_['import_sys'] = 'import sys';
  Blockly.Python.definitions_['import_resource_player'] = "sys.path.append('/home/scope/interface/resources')\nimport ResourcePlayer";
  var code = "ResourcePlayer.play('"+musicname+"',is_music=True)\n";
  return code;
};



/** 设置播放视频 */ 
Blockly.Blocks['play_video'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(PLAY_HUE);
    this.appendDummyInput()
        .appendField('播放视频')
        .appendField(new Blockly.FieldDropdown([
                       ['熊出没第1集', '熊出没1.mp4'],
                       ['熊出没第2集', '熊出没2.mp4'],
                       ['熊出没第3集', '熊出没3.mp4'],
                       ['熊出没第4集', '熊出没4.mp4']
                     ]),'VIDEO_NAME');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('播放视频');
  }
};


Blockly.Python['play_video'] = function(block) {

  var musicname = block.getFieldValue('VIDEO_NAME');
  Blockly.Python.definitions_['import_sys'] = 'import sys';
  Blockly.Python.definitions_['import_resource_player'] = "sys.path.append('/home/scope/interface/resources')\nimport ResourcePlayer";
  var code = "ResourcePlayer.play('"+musicname+"',is_movie=True)\n";
  return code;
};


/** 设置播放钢琴语音 */ 
Blockly.Blocks['play_piano'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(PLAY_HUE);
    this.appendDummyInput()
        .appendField('播放音符')
        .appendField(new Blockly.FieldDropdown([
                       ['do', 'do.mp3'],
                       ['re', 're.mp3'],
                       ['mi', 'mi.mp3'],
                       ['fa', 'fa.mp3'],
                       ['sol', 'so.mp3'],
                       ['la', 'la.mp3'],
                       ['si', 'xi.mp3']
                     ]),'PIANO_NAME');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('播放音符');
  }
};


Blockly.Python['play_piano'] = function(block) {

  var musicname = block.getFieldValue('PIANO_NAME');
  Blockly.Python.definitions_['import_sys'] = 'import sys';
  Blockly.Python.definitions_['import_resource_player'] = "sys.path.append('/home/scope/interface/resources')\nimport ResourcePlayer";
  var code = "ResourcePlayer.play('"+musicname+"',is_piano=True)\n";
  return code;
};


