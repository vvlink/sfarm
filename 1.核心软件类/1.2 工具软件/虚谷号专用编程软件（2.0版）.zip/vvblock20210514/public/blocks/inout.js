'use strict';

var INOUT_HUE = 15;

var pin_array=[['0', 'Pin.D0'],  
			   ['1', 'Pin.D1'],
			   ['2', 'Pin.D2'],
			   ['3', 'Pin.D3'],
			   ['4', 'Pin.D4'],
			   ['5', 'Pin.D5'],
			   ['6', 'Pin.D6'],
			   ['7', 'Pin.D7'],
			   ['8', 'Pin.D8'],
			   ['9', 'Pin.D9'],
			   ['10', 'Pin.D10'],
			   ['11', 'Pin.D11'],
			   ['12', 'Pin.D12'],
			   ['13', 'Pin.D13'],
			   ['A0', 'Pin.A0'],
			   ['A1', 'Pin.A1'],
			   ['A2', 'Pin.A2'],
			   ['A3', 'Pin.A3'],
			   ['A4', 'Pin.A4'],
			   ['A5', 'Pin.A5']];

var analog_pin=[['A0', 'Pin.A0'],
			   ['A1', 'Pin.A1'],
			   ['A2', 'Pin.A2'],
			   ['A3', 'Pin.A3'],
			   ['A4', 'Pin.A4'],
			   ['A5', 'Pin.A5']];	

var pwm_pin=[['3', 'Pin.D3'],
			   ['5', 'Pin.D5'],
			   ['6', 'Pin.D6'],
			   ['9', 'Pin.D9'],
			   ['10', 'Pin.D10'],
			   ['11', 'Pin.D11']];	   
			   
			   

     


/**数字引脚的数值读取*/
Blockly.Blocks['digital_read'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(INOUT_HUE);
    this.appendDummyInput()
        .appendField('读取数字引脚')
    .appendField(new Blockly.FieldDropdown(pin_array) ,'PIN');		
    this.setInputsInline(true);
    this.setOutput(true, 'Number')
    this.setTooltip('用于获取按键控制器的状态');
  }
};

Blockly.Python['digital_read'] = function(block) {
  var buttonpin =block.getFieldValue('PIN');
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  
  var code = "Pin("+buttonpin+",Pin.IN).read_digital()";
  return [code,Blockly.Python.ORDER_MEMBER];
};



/**数字引脚高低电平的设置*/
Blockly.Blocks['digital_write'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(INOUT_HUE);
    this.appendDummyInput()
        .appendField('数字引脚')
        .appendField(new Blockly.FieldDropdown(pin_array) ,'PIN');	
    this.appendDummyInput()
        .appendField('电平设置为')
    this.appendDummyInput()
        .appendField(new Blockly.FieldDropdown([
                       ['开', '1'],
                       ['关', '0']
                     ]),'STATE');

    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('用于开启或者关闭蜂鸣器');
  }
};

Blockly.Python['digital_write'] = function(block) {
  var state = block.getFieldValue('STATE');
  var pin =block.getFieldValue('PIN');
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  
 

  var code ="";
  var on="False";
  if(state=="1") {
     code = "Pin("+pin+",Pin.OUT).write_digital(1)\n";
  }else{
	  code = "Pin("+pin+",Pin.OUT).write_digital(0)\n";
  }

  return code;
};


/**获取模拟输入值*/
Blockly.Blocks['analog_read'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(INOUT_HUE);
    this.appendDummyInput()
        .appendField('获取模拟输入引脚')
        .appendField(new Blockly.FieldDropdown(analog_pin) ,'ANALOG_PIN');    
    this.setInputsInline(true);
    this.setOutput(true, 'Number')
    this.setTooltip('用于获取模拟输入返回的数值');
  }
};

Blockly.Python['analog_read'] = function(block) {
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  
  var pin = block.getFieldValue("ANALOG_PIN");
  var code = "Pin("+pin+",Pin.ANALOG).read_analog()";
  return [code,Blockly.Python.ORDER_MEMBER];
};





/**设置模拟输入*/
Blockly.Blocks['pwm_write'] = {
  init: function() {
        this.setHelpUrl('');
    this.setColour(INOUT_HUE);
    this.appendDummyInput()
        .appendField('设置模拟输出引脚')
        .appendField(new Blockly.FieldDropdown(pwm_pin) ,'ANALOG_PIN')
        .appendField("值为");
	this.appendValueInput('PWM_VALUE')
		.setCheck("Number")
    this.setInputsInline(true);
	this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('用于设置模拟输入值');
  }
};

Blockly.Python['pwm_write'] = function(block) {
  Blockly.Python.definitions_['import_pinpong'] = "from pinpong.board import *";
  Blockly.Python.definitions_['pinpong_begin'] = 'Board("xugu").begin()';  
  var pin = block.getFieldValue("ANALOG_PIN");
  var pwmvalue = Blockly.Python.valueToCode(block, 'PWM_VALUE', Blockly.JavaScript.ORDER_ATOMIC);
  var code = "Pin("+pin+",Pin.PWM).write_analog("+pwmvalue+")\n";
  return code;
};


/**设置模拟输入*/
Blockly.Blocks['value_map'] = {
  init: function() {
        this.setHelpUrl('');
    this.setColour(INOUT_HUE);
    this.appendDummyInput()
        .appendField('将值');
	this.appendValueInput('VALUE')
		.setCheck("Number");
       		
    this.appendDummyInput().appendField('从');
	this.appendValueInput('fromLow')
		.setCheck("Number");	
    this.appendDummyInput().appendField('到');
	this.appendValueInput('fromHigh')
		.setCheck("Number");	
    this.appendDummyInput().appendField('映射到');
	this.appendValueInput('toLow')
		.setCheck("Number");	
	this.appendDummyInput().appendField('至');	
    this.appendValueInput('toHigh')
		.setCheck("Number");
    this.appendDummyInput().appendField('之间');		
    
    this.setOutput(true, 'Number')
    this.setTooltip('把一个数从一个范围变换到另一个范围');
  }
};

Blockly.Python['value_map'] = function(block) {
  
  Blockly.Python.definitions_['value_map_function'] = 'def find_max(x,in_min,in_max,out_min,out_max):\n'
  +" return (x - in_min)*(out_max - out_min)/(in_max - in_min) + out_min ";  
  var value = Blockly.Python.valueToCode(block, 'VALUE', Blockly.JavaScript.ORDER_ATOMIC) ;
  var fromLow = Blockly.Python.valueToCode(block, 'fromLow', Blockly.JavaScript.ORDER_ATOMIC) ;
  var fromHigh = Blockly.Python.valueToCode(block, 'fromHigh', Blockly.JavaScript.ORDER_ATOMIC) ;
  var toLow = Blockly.Python.valueToCode(block, 'toLow', Blockly.JavaScript.ORDER_ATOMIC) ;
  var toHigh = Blockly.Python.valueToCode(block, 'toHigh', Blockly.JavaScript.ORDER_ATOMIC);
  var code="int(find_max("+value+","+fromLow+","+fromHigh+","+toLow+","+toHigh+"))";
  return [code,Blockly.Python.ORDER_MEMBER];
};












