'use strict';

/** Common HSV hue for all blocks in this category. */
var OBJECT_HUE = 160;

/** 识别语音 */
Blockly.Blocks['start_object_recog'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(OBJECT_HUE);
    this.appendDummyInput()
        .appendField('开始对象识别');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('object recognition');
  }
};

Blockly.Python['start_object_recog'] = function(block) {
  Blockly.Python.definitions_['import_cv2'] = 'import cv2\n';
  Blockly.Python.definitions_['import_numpy'] = 'import numpy as np\n';
  Blockly.Python.definitions_['import_operator'] = 'import operator\n';
  Blockly.Python.definitions_['import_os'] = 'import os\n';
  Blockly.Python.definitions_['import_ospath'] = 'import os.path\n';
  Blockly.Python.definitions_['import_re'] = 'import re\n';
  Blockly.Python.definitions_['import_sleep'] = 'from time import sleep\n';
  Blockly.Python.definitions_['import_tensorflow'] = 'import tensorflow as tf\n';
  Blockly.Python.definitions_['import_time'] = 'import time\n';
  Blockly.Python.definitions_['import_thread'] = 'from threading import Thread\n';


  Blockly.Python.definitions_['model_dir'] = "model_dir = /home/pi/test/tensorflow/imageclassification/Classification/model\n";
  
  Blockly.Python.definitions_['def_class_videostream'] = "class VideoStream():\n"
    +"def __init__(self, src=0):\n"
    +"    self.stream = cv2.VideoCapture(src)\n"
    +"    (self.grabbed, self.frame) = self.stream.read()\n"
    +"    self.stopped = False\n"
    +"def start(self):\n"
    +"    Thread(target=self.update, args=()).start()\n"
    +"    return self\n"
    +"def update(self):\n"
    +"    while True:\n"
    +"        if self.stopped:\n"
    +"            return\n"
    +"        (self.grabbed, self.frame) = self.stream.read()\n"
    +"def read(self):\n"
    +"    return self.frame\n"
    +"def stop(self):\n"
    +"    self.stopped = True\n";
    
  Blockly.Python.definitions_['def_class_nodelookup'] = "class NodeLookup(object):\n"
    +"def __init__(self,label_lookup_path=None,uid_lookup_path=None):\n"
    +"    if not label_lookup_path:\n"
    +"        label_lookup_path = os.path.join(model_dir, 'imagenet_2012_challenge_label_map_proto.pbtxt')\n"
    +"    if not uid_lookup_path:\n"
    +"        uid_lookup_path = os.path.join(model_dir, 'imagenet_synset_to_human_label_map.txt')\n"
    +"    self.node_lookup = self.load(label_lookup_path, uid_lookup_path)\n"
    +"def load(self, label_lookup_path, uid_lookup_path):\n"
    +"    if not tf.gfile.Exists(uid_lookup_path):\n"
    +"        tf.logging.fatal('File does not exist %s', uid_lookup_path)\n"
    +"    if not tf.gfile.Exists(label_lookup_path):\n"
    +"        tf.logging.fatal('File does not exist %s', label_lookup_path)\n"
    +"    proto_as_ascii_lines = tf.gfile.GFile(uid_lookup_path).readlines()\n"
    +"    uid_to_human = {}\n"
    +"    p = re.compile(r'[n\d]*[ \S,]*')\n"
    +"    for line in proto_as_ascii_lines:\n"
    +"        parsed_items = p.findall(line)\n"
    +"        uid = parsed_items[0]\n"
    +"        human_string = parsed_items[2]\n"
    +"        uid_to_human[uid] = human_string\n"
    +"    node_id_to_uid = {}\n"
    +"    proto_as_ascii = tf.gfile.GFile(label_lookup_path).readlines()\n"
    +"    for line in proto_as_ascii:\n"
    +"        if line.startswith('  target_class:'):\n"
    +"            target_class = int(line.split(': ')[1])\n"
    +"        if line.startswith('  target_class_string:'):\n"
    +"            target_class_string = line.split(': ')[1]\n"
    +"            node_id_to_uid[target_class] = target_class_string[1:-2]\n"
    +"    node_id_to_name = {}\n"
    +"    for key, val in node_id_to_uid.items():\n"
    +"        if val not in uid_to_human:\n"
    +"            tf.logging.fatal('Failed to locate: %s', val)\n"
    +"        name = uid_to_human[val]\n"
    +"        node_id_to_name[key] = name\n"
    +"    return node_id_to_name\n"
    +"def id_to_string(self, node_id):\n"
    +"    if node_id not in self.node_lookup:\n"
    +"        return ''\n"
    +"    return self.node_lookup[node_id]\n";



  Blockly.Python.definitions_['def_create_graph'] = "def create_graph():\n"
    +"with tf.gfile.FastGFile(os.path.join(model_dir, 'classify_image_graph_def.pb'), 'rb') as f:\n"
    +"    graph_def = tf.GraphDef()\n"
    +"    graph_def.ParseFromString(f.read())\n"
    +"    _ = tf.import_graph_def(graph_def, name='')\n";
        
  Blockly.Python.definitions_['def_init_create_graph'] = "create_graph()\n";
  Blockly.Python.definitions_['def_init_videostream'] = "vs = VideoStream(src=1).start()\n";
   
  
  var code = "with tf.Session() as sess:\n"
    +"softmax_tensor = sess.graph.get_tensor_by_name('softmax:0')\n"
    +"while True:\n"
    +"    score = 0\n"
    +"    human_string = None\n"
    +"    frame = vs.read()\n"
    +"    cv2.imwrite('/home/pi/test/tensorflow/imageclassification/Classification/current_frame.jpg', frame)\n"
    +"    image_data = tf.gfile.FastGFile('/home/pi/test/tensorflow/imageclassification/Classification/current_frame.jpg', 'rb').read()\n"
    +"    predictions = sess.run(softmax_tensor, {'DecodeJpeg/contents:0': image_data})\n"
    +"    predictions = np.squeeze(predictions)\n"
    +"    node_lookup = NodeLookup()\n"
    +"    n_pred = 1\n"
    +"    top_k = predictions.argsort()[-n_pred:][::-1]\n"
    +"    for node_id in top_k:\n"
    +"        human_string_n = node_lookup.id_to_string(node_id)\n"
    +"        score = predictions[node_id]\n"
    +"    if score > .5:\n"
    +"        if human_string_n == 'stethoscope':\n"
    +"            human_string_n = 'Headphones'\n"
    +"        if human_string_n == 'spatula':\n"
    +"            human_string_n = 'fork'\n"
    +"        if human_string_n == 'iPod':\n"
    +"            human_string_n = 'iPhone'\n"
    +"        human_string = human_string_n\n"
    +"        lst = human_string.split()\n"
    +"        human_string = ' '.join(lst[0:2])\n"
    +"        human_string_filename = str(lst[0])\n"
    +"    cv2.putText(frame, human_string, (20, 400),cv2.FONT_HERSHEY_TRIPLEX, 1, (255, 255, 255))\n"
    +"    cv2.putText(frame, str(np.round(score, 2)) + '%',(20, 440), cv2.FONT_HERSHEY_TRIPLEX, 1, (255, 255, 255))\n"
    +"    cv2.imshow('Frame', frame)\n";
            
            
  return code;
};


Blockly.Blocks['end_object_recog'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(OBJECT_HUE);
    this.appendDummyInput()
        .appendField('结束对象识别');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('object recognition end');
  }
};

Blockly.Python['end_object_recog'] = function(block) {
   var code = 'vs.stop()\n'
    +"cv2.destroyAllWindows()\n"  
    +"sess.close()\n";
  return code;
};

/** 识别语音 */
Blockly.Blocks['object_recog_result'] = {
  init: function() {
    this.setHelpUrl('');
    this.setColour(OBJECT_HUE);
    this.setOutput(true, 'String');
    this.appendDummyInput().appendField('对象识别结果');
    this.setTooltip('object recognition result');
  }
};

Blockly.Python['object_recog_result'] = function(block) {
  var code = 'human_string';
  return [code,Blockly.Python.ORDER_MEMBER];
};