/**
 * @license Licensed under the Apache License, Version 2.0 (the "License"):
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 * @fileoverview Description.
 */
'use strict';

/** Common HSV hue for all blocks in this category. */
var WIFI_HUE = 325;


Blockly.Blocks['wifi_connect'] = {
  init: function() {
    this.setColour(WIFI_HUE);
	this.appendDummyInput()
        .appendField('连接WIFI名称');
    this.appendValueInput('WIFI_SSID')
    .setCheck("String")
    .appendField("WIFI名称");
    this.appendValueInput('WIFI_PWD')
    .setCheck("String")
    .appendField("密码");
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip("连接WIFI");
  }
};

Blockly.Python['wifi_connect']=function(block){
    Blockly.Python.definitions_['import_wfi_helper'] = 'from interface.common import wifihelper';
    var ssid = Blockly.Python.valueToCode(block, 'WIFI_SSID', Blockly.JavaScript.ORDER_ATOMIC) ;
	var pwd = Blockly.Python.valueToCode(block, 'WIFI_PWD', Blockly.JavaScript.ORDER_ATOMIC) ;
    var code = "wifihelper.connection_wifi("+ssid+","+pwd+")\n";
	return code;
};



Blockly.Blocks['wifi_connect_state'] = {
  init: function() {
    this.setColour(WIFI_HUE);
	this.appendDummyInput()
        .appendField('已连接上WIFI');
    this.setOutput(true,'Boolean')		
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip("获取WIFI连接状态");
  }
};

Blockly.Python['wifi_connect_state']=function(block){
    Blockly.Python.definitions_['import_wfi_helper'] = 'from interface.common import wifihelper';
    var code = 'wifihelper.is_connected()';
	return [code,Blockly.Python.ORDER_MEMBER];
};


Blockly.Blocks['wifi_disconnect'] = {
  init: function() {
    this.setColour(WIFI_HUE);
	this.appendDummyInput()
        .appendField('断开WIFI连接');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip("断开WIFI连接");
  }
};

Blockly.Python['wifi_disconnect']=function(block){
   Blockly.Python.definitions_['import_wfi_helper'] = 'from interface.common import wifihelper';
    var code = 'wifihelper.disconnect_wifi()\n';
	return code;
};


Blockly.Blocks['get_connecting_ipaddress'] = {
  init: function() {
    this.setColour(WIFI_HUE);
	this.appendDummyInput()
        .appendField('获取连接WIFI的IP地址');
	this.setOutput(true, 'String')	
    this.setInputsInline(true);

    this.setTooltip("获取当前连接wifi的ip地址");
  }
};

Blockly.Python['get_connecting_ipaddress']=function(block){
    Blockly.Python.definitions_['import_wfi_helper'] = 'from interface.common import wifihelper';
    var code = 'wifihelper.get_current_wifi_info()[1]';
	return [code,Blockly.Python.ORDER_MEMBER];
};


Blockly.Blocks['get_connecting_wifi_name'] = {
  init: function() {
    this.setColour(WIFI_HUE);
	this.appendDummyInput()
        .appendField('获取连接WIFI的wifi名称');
    this.setOutput(true, 'String')			
    this.setInputsInline(true);

    this.setTooltip("获取连接WIFI的wifi名称");
  }
};

Blockly.Python['get_connecting_wifi_name']=function(block){
    Blockly.Python.definitions_['import_wfi_helper'] = 'from interface.common import wifihelper';
    var code = 'wifihelper.get_current_wifi_info()[0]';
	return [code,Blockly.Python.ORDER_MEMBER];
};


Blockly.Blocks['wifi_reset'] = {
  init: function() {
    this.setColour(WIFI_HUE);
	this.appendDummyInput()
        .appendField('重置wifi');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip("删除wifi的所有连接信息");
  }
};

Blockly.Python['wifi_reset']=function(block){
    Blockly.Python.definitions_['import_wfi_helper'] = 'from interface.common import wifihelper';
    var code = 'wifihelper.reset_wifi_info()\n';
	return code;
};



