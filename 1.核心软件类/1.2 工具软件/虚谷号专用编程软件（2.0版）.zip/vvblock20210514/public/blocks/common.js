/**
 * @license Licensed under the Apache License, Version 2.0 (the "License"):
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 * @fileoverview Description.
 */
'use strict';

/** Common HSV hue for all blocks in this category. */
var WIFI_HUE = 360;


Blockly.Blocks['reboot_device'] = {
  init: function() {
    this.setColour(WIFI_HUE);
	this.appendDummyInput()
        .appendField('重启设备');
    this.setInputsInline(true);
    this.setPreviousStatement(true);

    this.setTooltip("重启设备");
  }
};

Blockly.Python['reboot_device']=function(block){
    Blockly.Python.definitions_['import_os'] = 'import os';

    var code = "os.system(\"reboot\")\n";
	return code;
};



Blockly.Blocks['get_current_ip'] = {
  init: function() {
    this.setColour(WIFI_HUE);
	this.appendDummyInput()
        .appendField('获取当前IP');
    this.setOutput(true,'String')		
    this.setInputsInline(true);

    this.setTooltip("获取当前IP");
  }
};

Blockly.Python['get_current_ip']=function(block){
    Blockly.Python.definitions_['import_os'] = 'import os';
	Blockly.Python.definitions_['def_os_command_get_ip'] = 'def get_ip_by_command(): \n'+
	                                               "  return os.popen(\"ifconfig | grep 'inet 地址:' | grep -v '127.0.0.1'|grep -v '192.168.8.8' | cut -d: -f2 | awk '{print $1}' | head \").read()\n"
    var code = "get_ip_by_command()";
	return [code,Blockly.Python.ORDER_MEMBER];
};





Blockly.Blocks['current_image_to_base64'] = {
  init: function() {
    this.setColour(WIFI_HUE);
	this.appendDummyInput()
        .appendField('获取当前图像的base64编码');
    this.setOutput(true, 'String')			
    this.setInputsInline(true);

    this.setTooltip("获取当前图像的base64编码");
  }
};

Blockly.Python['current_image_to_base64']=function(block){
    Blockly.Python.definitions_['import_sysutils'] = 'from interface.common import sysutils';
	Blockly.Python.definitions_['import_base64'] = 'import base64';
	Blockly.Python.definitions_['import_cv2'] = 'import cv2';
	Blockly.Python.definitions_['def_currentimage_tobase64'] = 'def parse_image_base64(): \n'+
	                                               '  image=sysutils.get_image_from_videocapture()\n'+
												   '  if(image is not None):\n'+
												   "     image=cv2.resize(image,(300,200))\n"+
												   "     cv2.imwrite('current_frame.jpg',image)\n"+
												   "     with open('current_frame.jpg','rb') as f:\n"+
												   '        base64_data = base64.b64encode(f.read())\n'+
												   '        return str(base64_data)\n'  
	                                        
	
	
    var code = 'parse_image_base64()';
	return [code,Blockly.Python.ORDER_MEMBER];
};






