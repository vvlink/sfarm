import sys
from time import sleep

sys.path.append('/home/pi/aicomer/voice')
import VoiceHelper


sys.path.append('/home/pi/aicomer/tftdisplay')
import EyeHelper

sys.path.append('/home/pi/aicomer/face')
import FaceHelper

sys.path.append('/home/pi/aicomer/gpio')
import ServoHelper





openstr=['我是','谁','识别','看看']


def handlresult():
    result=VoiceHelper.get_voice_result()
    if(not result is None):
          for key in openstr:
              if(key in result):
                  result=FaceHelper.get_photo_result()
                  if(not result is None and result!="我不认识你"):
                      VoiceHelper.say('欢迎回家:'+result)
                      ServoHelper.setAngle(15,0)
                      EyeHelper.display(EyeHelper.HIGH)
                      sleep(2)
                      EyeHelper.display(EyeHelper.CLOSE)
                  else:
                      VoiceHelper.say('我不认识你')
                  break     
#语音识别 获取温度
while True:
      handlresult()
    
                  




