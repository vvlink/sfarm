import sys


sys.path.append('/home/pi/aicomer/voice')
import VoiceHelper

sys.path.append('/home/pi/aicomer/tftdisplay')
import EyeHelper

def display(flag,count):
    num=0
    while num<count:
         num+=1
         EyeHelper.display(flag)

def handlresult():
    result=VoiceHelper.get_voice_result()
    if(result is None):
         return

    if('卖萌' in result or  '萌' in result):
          display(EyeHelper.LOVELY,3)

    if('技' in result or  '杂' in result ):
          display(EyeHelper.ZAJI,3)

    if('生气' in result or  '气' in result ):
          display(EyeHelper.ANGRY,3)

    if('你好' in result or  '您好' in result or 'hello' in result ):
          display(EyeHelper.HELLO,3)
      

                 
#语音识别 获取温度
while True:
      handlresult()
    
                  




