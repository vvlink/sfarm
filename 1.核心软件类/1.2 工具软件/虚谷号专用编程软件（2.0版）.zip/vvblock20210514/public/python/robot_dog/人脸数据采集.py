import sys

num = None
count = None

sys.path.append('/home/pi/aicomer/voice')
import VoiceHelper

sys.path.append('/home/pi/aicomer/face')
import FaceHelper


VoiceHelper.set_bspd(5)
VoiceHelper.set_bvol(9)
VoiceHelper.set_bpit(6)
VoiceHelper.set_bper(0)
num = 0
count = 20
VoiceHelper.say('主人我准备好了')
while True:
  if FaceHelper.get_photo_issuccess():
    if num < count:
      num = num + 1
  if num < count:
    if num == 0:
      VoiceHelper.say('第1次')
    if num > 0:
      VoiceHelper.say((str('第') + str(str(num) + str('次'))))
  if num >= count:
    VoiceHelper.say('人脸采集完成')
